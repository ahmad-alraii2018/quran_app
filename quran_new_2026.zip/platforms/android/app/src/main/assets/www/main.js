const quranData = [
    { name: "الفاتحة", text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ﴿١﴾ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ﴿٢﴾ الرَّحْمَٰنِ الرَّحِيمِ ﴿٣﴾ مَالِكِ يَوْمِ الدِّينِ ﴿٤﴾ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ﴿٥﴾ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ﴿٦﴾ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ﴿٧﴾" },
    { name: "الملك", text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ ﴿١﴾ الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا وَهُوَ الْعَزِيزُ الْغَفُورُ ﴿٢﴾ الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا مَّا تَرَى فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ فَارْجِعِ الْبَصَرَ هَلْ تَرَى مِن فُطُورٍ ﴿٣﴾ ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ ﴿٤﴾ وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ ﴿٥﴾ وَلِلَّذِينَ كَفَرُوا بِرَبِّهِمْ عَذَابُ جَهَنَّمَ وَبِئْسَ الْمَصِيرُ ﴿٦﴾ إِذَا أُلْقُوا فِيهَا سَمِعُوا لَهَا شَهِيقًا وَهِيَ تَفُورُ ﴿٧﴾ تَكَادُ تَمَيَّزُ مِنَ الْغَيْظِ كُلَّمَا أُلْقِيَ فِيهَا فَوْجٌ سَأَلَهُمْ خَزَنَتُهَا أَلَمْ يَأْتِكُمْ نَذِيرٌ ﴿٨﴾ قَالُوا بَلَى قَدْ جَاءَنَا نَذِيرٌ فَكَذَّبْنَا وَقُلْنَا مَا نَزَّلَ اللَّهُ مِن شَيْءٍ إِنْ أَنتُمْ إِلَّا فِي ضَلَالٍ كَبِيرٍ ﴿٩﴾ وَقَالُوا لَوْ كُنَّا نَسْمَعُ أَوْ نَعْقِلُ مَا كُنَّا فِي أَصْحَابِ السَّعِيرِ ﴿١٠﴾ فَاعْتَرَفُوا بِذُنْبِهِمْ فَسُحْقًا لِّأَصْحَابِ السَّعِيرِ ﴿١١﴾ إِنَّ الَّذِينَ يَخْشَوْنَ رَبَّهُم بِالْغَيْبِ لَهُم مَّغْفِرَةٌ وَأَجْرٌ كَبِيرٌ ﴿١٢﴾ وَأَسِرُّوا قَوْلَكُمْ أَوِ اجْهَرُوا بِهِ إِنَّهُ عَلِيمٌ بِذَاتِ الصُّدُورِ ﴿١٣﴾ أَلَا يَعْلَمُ مَنْ خَلَقَ وَهُوَ اللَّطِيفُ الْخَبِيرُ ﴿١٤﴾ هُوَ الَّذِي جَعَلَ لَكُمُ الْأَرْضَ ذَلُولًا فَامْشُوا فِي مَنَاكِبِهَا وَكُلُوا مِن رِّزْقِهِ وَإِلَيْهِ النُّشُورُ ﴿١٥﴾" },
    { name: "يس (صدر السورة)", text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ. يس ﴿١﴾ وَالْقُرْآنِ الْحَكِيمِ ﴿٢﴾ إِنَّكَ لَمِنَ الْمُرْسَلِينَ ﴿٣﴾ عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ ﴿٤﴾ تَنزيلَ الْعَزِيزِ الرَّحِيمِ ﴿٥﴾ لِتُنذِرَ قَوْمًا مَّا أُنذِرَ آبَاؤُهُمْ فَهُمْ غَافِلُونَ ﴿٦﴾ لَقَدْ حَقَّ الْقَوْلُ عَلَىٰ أَكْثَرِهِمْ فَهُمْ لَا يُؤْمِنُونَ ﴿٧﴾ إِنَّا جَعَلْنَا فِي أَعْنَاقِهِمْ أَغْلَالًا فَهِيَ إِلَى الْأَذْقَانِ فَهُم مُّقْمَحُونَ ﴿٨﴾ وَجَعَلْنَا مِن بَيْنِ أَيْدِيهِمْ سَدًّا وَمِنْ خَلْفِهِمْ سَدًّا فَأَغْشَيْنَاهُمْ فَهُمْ لَا يُبْصِرُونَ ﴿٩﴾" },
    { name: "الإخلاص", text: "قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾ اللَّهُ الصَّمَدُ ﴿٢﴾ لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴿٤﴾" },
    { name: "الفلق", text: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ﴿١﴾ مِن شَرِّ مَا خَلَقَ ﴿٢﴾ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبُ ﴿٣﴾ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ﴿٤﴾ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴿٥﴾" },
    { name: "الناس", text: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ﴿١﴾ مَلِكِ النَّاسِ ﴿٢﴾ إِلَٰهِ النَّاسِ ﴿٣﴾ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ﴿٤﴾ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ﴿٥﴾ مِنَ الْجِنَّةِ وَالنَّاسِ ﴿٦﴾" }
];

const dailyAzkar = [
    { text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", target: 1, hint: "أذكار الصباح والمساء الأساسية" },
    { text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.", target: 3, hint: "الفضل: حماية تامة من الهوام والشرور طوال الليل واليوم." },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.", target: 1, hint: "سيد الاستغفار: من قالها ومات من يومه دخل الجنة." },
    { text: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءfloatِ وَهُوَ السَّمِيعُ الْعَلِيمُ.", target: 3, hint: "الفضل: لم يضره شيء ولم تصبه فجأة بلاء." },
    { text: "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.", target: 3, hint: "الفضل: صلاح الأحوال وصيانة النفس من الشتات والتعب." },
    { text: "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ.", target: 7, hint: "الفضل: كفاه الله ما أهمه من أمر الدنيا والآخرة غصباً عن أي ضيق." },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، عَدَدَ خَلْقِهِ ، وَرِضَا نَفْسِهِ ، وَزِنَةَ عَرْشِهِ ، وَمِدَادَ كَلِمَاتِهِ.", target: 3, hint: "الفضل: تعدل ساعات طويلة من الذكر والتسبيح المتواصل." },
    { text: "اللَّهُمَّ عافِني في بَدَني، اللَّهُمَّ عافِني في سَمْعي، اللَّهُمَّ عافِني في بَصَري، لا إلهَ إلَّا أنتَ.", target: 3, hint: "طلب العافية وصيانة الجسد والبدن يومياً." }
];

window.switchPage = function(pageId, btn) {
    const pages = document.getElementsByClassName('app-page');
    for (let i = 0; i < pages.length; i++) { pages[i].classList.remove('active'); }
    document.getElementById(pageId).classList.add('active');
    const buttons = document.getElementsByClassName('tab-btn');
    for (let i = 0; i < buttons.length; i++) { buttons[i].classList.remove('active'); }
    btn.classList.add('active');
};

function generateQuranReader() {
    const directory = document.getElementById('surah-directory');
    if (!directory) return;
    let htmlContent = '';
    quranData.forEach((surah, index) => {
        htmlContent += `
            <div class="surah-card" data-name="${surah.name}">
                <div class="surah-header-text">سورة ${surah.name}</div>
                <p class="surah-text-content">${surah.text}</p>
            </div>
        `;
    });
    directory.innerHTML = htmlContent;
}

const searchInput = document.getElementById('search-input');
if (searchInput) {
    searchInput.addEventListener('keyup', function() {
        const query = this.value.trim().toLowerCase();
        const cards = document.getElementsByClassName('surah-card');
        for (let i = 0; i < cards.length; i++) {
            const card = cards[i]; const name = card.getAttribute('data-name').toLowerCase();
            if (name.includes(query)) { card.style.display = 'block'; } else { card.style.display = 'none'; }
        }
    });
}

const tasbeehAzkar = ["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", "لا حَوْلَ وَلا قُوَّةَ إِلا بِاللَّهِ", "لا إِلَهَ إِلا اللَّهُ"];
let tasbeehCount = 0, tasbeehIndex = 0;

const tasbeehClickBtn = document.getElementById('tasbeeh-click-btn');
if (tasbeehClickBtn) {
    tasbeehClickBtn.addEventListener('click', function() {
        tasbeehCount++; document.getElementById('tasbeeh-num').innerText = tasbeehCount; if (navigator.vibrate) navigator.vibrate(45);
        if (tasbeehCount % 33 === 0) { tasbeehIndex = (tasbeehIndex + 1) % tasbeehAzkar.length; document.getElementById('tasbeeh-zikr').innerText = `"${tasbeehAzkar[tasbeehIndex]}"`; }
    });
}

const resetTasbeehBtn = document.getElementById('reset-tasbeeh-btn');
if (resetTasbeehBtn) {
    resetTasbeehBtn.addEventListener('click', function() { tasbeehCount = 0; document.getElementById('tasbeeh-num').innerText = tasbeehCount; });
}

function buildAzkarDirectory() {
    const container = document.getElementById('azkar-directory'); if (!container) return;
    let html = '';
    dailyAzkar.forEach((item, index) => {
        html += `
            <div class="text-card">
                <p class="card-main-text">${item.text}</p>
                <div class="azkar-meta">
                    <span class="card-hint">${item.hint}</span>
                    <button class="azkar-count-btn" id="azkar-btn-${index}" onclick="countZikrCard(${index}, ${item.target})">المتبقي: ${item.target}</button>
                </div>
            </div>
        `;
    });
    container.innerHTML = html;
}

window.countZikrCard = function(index, targetCount) {
    const btn = document.getElementById(`azkar-btn-${index}`); if (!btn || btn.classList.contains('done')) return;
    let currentNum = parseInt(btn.innerText.replace(/[^0-9]/g, '')) - 1; if (navigator.vibrate) navigator.vibrate(35);
    if (currentNum <= 0) { btn.innerText = "تم بحمد الله ✓"; btn.classList.add('done'); } else { btn.innerText = `المتبقي: ${currentNum}`; }
};

generateQuranReader(); buildAzkarDirectory();
